/**
 * Split a string into Unicode code points. Pali words use precomposed
 * diacritics (ā, ṃ, ñ…), so a plain index-based split would miscount.
 */
export function toChars(s: string): string[] {
  return Array.from(s);
}
