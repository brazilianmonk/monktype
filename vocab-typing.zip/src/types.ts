export interface WordEntry {
  word: string;
  meaning: string;
  /**
   * IPA pronunciation, e.g. "/əˈbɪləti/". Mainly for English lists; leave
   * unset for other languages (e.g. Pali) and it will not be displayed.
   */
  ipa?: string;
}

export interface WordList {
  id: string;
  name: string;
  source: "file" | "custom";
  words: WordEntry[];
}

export type Theme = "dark" | "light";

/** A finished word within a test. */
export interface Completion {
  entry: WordEntry;
  /** What the user actually typed (may include extra characters). */
  typed: string;
  /** Number of incorrect characters in this word. */
  errors: number;
  /** Elapsed time at completion, in ms. */
  t: number;
  /** Net WPM at completion. */
  wpm: number;
}

/** A completed test, kept for the history view. */
export interface HistoryEntry {
  date: number;
  listId: string;
  listName: string;
  count: number;
  wpm: number;
  raw: number;
  acc: number;
  errors: number;
  durationMs: number;
}
