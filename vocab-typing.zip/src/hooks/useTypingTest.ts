import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Completion, WordEntry } from "../types";
import { netWpm } from "../utils/stats";
import { toChars } from "../utils/text";

export type TestStatus = "idle" | "running" | "finished";

export interface TypingStats {
  correct: number;
  errors: number;
  extra: number;
}

export interface TypingTest {
  words: WordEntry[];
  status: TestStatus;
  wordIndex: number;
  /** What the user typed for each word (only indices <= wordIndex are meaningful). */
  typed: string[];
  completions: Completion[];
  /** The most recently finished word, shown in the meaning panel. */
  lastMeaning: WordEntry | null;
  elapsedMs: number;
  stats: TypingStats;
  inputRef: React.RefObject<HTMLInputElement>;
  onInput: (e: React.FormEvent<HTMLInputElement>) => void;
  onKeyDown: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  restart: () => void;
  newTest: () => void;
  focusInput: () => void;
}

/** Fisher–Yates shuffle, then take the first `count`. */
export function pickWords(list: WordEntry[], count: number): WordEntry[] {
  const n = Math.min(count, list.length);
  const pool = list.slice();
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, n);
}

export function useTypingTest(list: WordEntry[], count: number): TypingTest {
  const [words, setWords] = useState<WordEntry[]>(() => pickWords(list, count));
  const [status, setStatus] = useState<TestStatus>("idle");
  const [wordIndex, setWordIndex] = useState(0);
  const [typed, setTyped] = useState<string[]>([]);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [now, setNow] = useState(0);
  const [completions, setCompletions] = useState<Completion[]>([]);
  const [lastMeaning, setLastMeaning] = useState<WordEntry | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const resetAll = useCallback((fresh: WordEntry[]) => {
    setWords(fresh);
    setStatus("idle");
    setWordIndex(0);
    setTyped(Array(fresh.length).fill(""));
    setStartTime(null);
    setNow(0);
    setCompletions([]);
    setLastMeaning(null);
    if (inputRef.current) inputRef.current.value = "";
    requestAnimationFrame(() => inputRef.current?.focus());
  }, []);

  // Start a fresh test whenever the list or word count changes.
  useEffect(() => {
    resetAll(pickWords(list, count));
  }, [list, count, resetAll]);

  // Tick the clock while the test is running.
  useEffect(() => {
    if (status !== "running") return;
    const id = window.setInterval(() => setNow(performance.now()), 250);
    return () => window.clearInterval(id);
  }, [status]);

  const elapsedMs = startTime === null ? 0 : now - startTime;

  const stats = useMemo<TypingStats>(() => {
    let correct = 0;
    let errors = 0;
    let extra = 0;
    for (let i = 0; i <= wordIndex && i < words.length; i++) {
      const tChars = toChars(typed[i] ?? "");
      const wChars = toChars(words[i].word);
      for (let j = 0; j < tChars.length; j++) {
        if (j < wChars.length) {
          if (tChars[j] === wChars[j]) correct++;
          else errors++;
        } else {
          extra++;
        }
      }
      // Finished words with skipped letters count them as errors.
      if (i < wordIndex && tChars.length < wChars.length) {
        errors += wChars.length - tChars.length;
      }
    }
    return { correct, errors, extra };
  }, [typed, wordIndex, words]);

  const finishWord = useCallback(() => {
    const entry = words[wordIndex];
    if (!entry) return;
    const t = typed[wordIndex] ?? "";
    const tChars = toChars(t);
    const wChars = toChars(entry.word);
    let wordErrors = 0;
    for (let j = 0; j < tChars.length; j++) {
      if (j >= wChars.length || tChars[j] !== wChars[j]) wordErrors++;
    }
    // Skipped letters count as errors too.
    if (tChars.length < wChars.length) wordErrors += wChars.length - tChars.length;
    const elapsed = startTime === null ? 0 : performance.now() - startTime;
    // Keep the displayed clock accurate when the test ends.
    setNow(performance.now());
    const completion: Completion = {
      entry,
      typed: t,
      errors: wordErrors,
      t: elapsed,
      wpm: netWpm(stats.correct, elapsed),
    };
    setCompletions((prev) => [...prev, completion]);
    setLastMeaning(entry);
    if (wordIndex === words.length - 1) {
      setStatus("finished");
    } else {
      setWordIndex((i) => i + 1);
      setTyped((prev) => {
        const next = prev.slice();
        next[wordIndex + 1] = "";
        return next;
      });
    }
    if (inputRef.current) inputRef.current.value = "";
  }, [words, wordIndex, typed, startTime, stats]);

  const onInput = useCallback(
    (e: React.FormEvent<HTMLInputElement>) => {
      // Strip any whitespace (e.g. from pasted text) — words never contain it.
      const raw = e.currentTarget.value;
      const value = raw.replace(/\s+/g, "");
      if (value !== raw) e.currentTarget.value = value;
      setTyped((prev) => {
        const next = prev.slice();
        next[wordIndex] = value;
        return next;
      });
      if (startTime === null) {
        setStartTime(performance.now());
        setNow(performance.now());
        setStatus("running");
      }
    },
    [wordIndex, startTime]
  );

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === "Tab") {
        // Restart with the same words.
        e.preventDefault();
        resetAll(words);
        return;
      }
      if (e.key === " ") {
        // Finish the current word. Space never reaches the input value.
        e.preventDefault();
        if (status === "running" && (typed[wordIndex] ?? "").length > 0) {
          finishWord();
        }
        return;
      }
      if (e.key === "Backspace") {
        const input = e.currentTarget;
        // At the start of a word, go back to the previous word.
        if (input.value.length === 0 && wordIndex > 0 && status === "running") {
          e.preventDefault();
          const prev = wordIndex - 1;
          setWordIndex(prev);
          input.value = typed[prev] ?? "";
        }
        return;
      }
    },
    [words, status, typed, wordIndex, resetAll, finishWord]
  );

  const restart = useCallback(() => resetAll(words), [resetAll, words]);
  const newTest = useCallback(() => resetAll(pickWords(list, count)), [resetAll, list, count]);
  const focusInput = useCallback(() => inputRef.current?.focus(), []);

  return {
    words,
    status,
    wordIndex,
    typed,
    completions,
    lastMeaning,
    elapsedMs,
    stats,
    inputRef,
    onInput,
    onKeyDown,
    restart,
    newTest,
    focusInput,
  };
}
